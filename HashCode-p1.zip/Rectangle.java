
/**
 * Write a description of class Rectangle here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Rectangle {
    int posx;
    int posy;
    char ingredient;
    
    public Rectangle(int x,int y,char ing){
        this.posx = x;
        this.posy = y;
        this.ingredient = ing;
    }    
}
